new Inventario();
new InfoContenedor();
new WithdrawForm();
new Inicio();