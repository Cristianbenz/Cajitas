class Premio {
    constructor(name, price, img, quality) {
        this.name = name;
        this.price = price;
        this.img = img;
        this.quality = quality;
    }
}