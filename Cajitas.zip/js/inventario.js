const CARGAR_INVENTARIO = new Inventario();
const CARGAR_INFO = new InfoContenedor();
const WITHDRAW_FORM = new WithdrawForm();
const NUEVO_INICIO = new Inicio();