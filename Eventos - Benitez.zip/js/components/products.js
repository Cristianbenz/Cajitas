class Premio {
    constructor(name, price, img) {
        this.name = name;
        this.price = price;
        this.img = img;
    }
}