const CARGAR_INVENTARIO = new Inventario();
const NUEVO_INICIO = new Inicio();